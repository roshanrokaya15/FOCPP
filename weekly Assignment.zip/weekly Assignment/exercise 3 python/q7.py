number = int(input("Enter a number (0–12) for the times table: "))
if 0 <= number <= 12:
    for i in range(13):  
        print(f"{i} * {number} = {i * number}")
else:
    print("Please enter a number between 0 and 12.")
for number in range(13):  
    result = number * 7
    print(f"{number} * 7 = {result}")

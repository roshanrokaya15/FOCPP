name = input("Enter your name: ")
if name == "":
    print("Hello, Stranger!")
else:
    print(f"Hello, {name}!")

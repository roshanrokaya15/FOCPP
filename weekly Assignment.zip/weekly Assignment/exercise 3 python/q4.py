BAD_PASSWORDS = ['password', 'letmein', 'sesame', 'hello', 'justinbieber']

password1 = input("Enter a new password (8–12 characters): ")

if len(password1) < 8 or len(password1) > 12:
    print("Error: Password must be between 8 and 12 characters long.")
elif password1 in BAD_PASSWORDS:
    print("Error: That password is too common.")
else:
    password2 = input("Re-enter your password: ")
    if password1 == password2:
        print("Password set successfully!")
    else:
        print("Error: Passwords do not match.")
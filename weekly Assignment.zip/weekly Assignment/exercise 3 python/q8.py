table = int(input("Enter a number (0–12). Use negative to print backwards: "))
number = abs(table)
if table >= 0:
    for i in range(13):  # 0 to 12
        print(f"{i} * {number} = {i * number}")
else:
    for i in range(12, -1, -1):  # 12 down to 0
        print(f"{i} * {number} = {i * number}")